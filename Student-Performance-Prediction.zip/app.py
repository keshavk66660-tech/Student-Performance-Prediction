import os
import numpy as np
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
import joblib

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, r2_score

st.set_page_config(
    page_title="Student Performance Prediction",
    page_icon="🎓",
    layout="wide"
)

@st.cache_resource
def load_model_data():
    model_path = "student_performance_model.pkl"
    data_path = "student_performance_dataset.csv"
    features_path = "feature_columns.pkl"

    # Saved files milne par unhe use karo
    if all(os.path.exists(p) for p in [
        model_path, data_path, features_path
    ]):
        model = joblib.load(model_path)
        data = pd.read_csv(data_path)
        features = joblib.load(features_path)
        return model, data, features

    # Files na hon to dataset aur model automatically banao
    rng = np.random.default_rng(42)
    n = 1000

    data = pd.DataFrame({
        "Attendance": rng.integers(40, 101, n),
        "StudyHours": np.round(rng.uniform(0.5, 8, n), 1),
        "PreviousMarks": rng.integers(25, 101, n),
        "AssignmentScore": rng.integers(20, 101, n)
    })

    noise = rng.normal(0, 7, n)
    marks = (
        0.30 * data["PreviousMarks"]
        + 0.25 * data["AssignmentScore"]
        + 0.25 * (data["Attendance"] * 0.8)
        + 0.20 * (data["StudyHours"] * 10)
        + noise
    )

    data["FinalMarks"] = np.clip(marks, 0, 100).round(1)
    data["Performance"] = np.where(
        data["FinalMarks"] >= 40, "Pass", "Needs Improvement"
    )

    features = [
        "Attendance", "StudyHours",
        "PreviousMarks", "AssignmentScore"
    ]

    X_train, X_test, y_train, y_test = train_test_split(
        data[features], data["FinalMarks"],
        test_size=0.2, random_state=42
    )

    models = {
        "Linear Regression": LinearRegression(),
        "Random Forest": RandomForestRegressor(
            n_estimators=150, random_state=42
        )
    }

    best_model = None
    best_mae = float("inf")

    for candidate in models.values():
        candidate.fit(X_train, y_train)
        mae = mean_absolute_error(
            y_test, candidate.predict(X_test)
        )
        if mae < best_mae:
            best_mae = mae
            best_model = candidate

    return best_model, data, features


try:
    model, df, features = load_model_data()
except Exception as e:
    st.error(f"Model or dataset load nahi hua: {e}")
    st.stop()

st.title("🎓 Student Performance Prediction System")
st.markdown(
    "### Machine Learning Based Academic Analytics Dashboard"
)
st.caption(
    "Educational demonstration project — predictions are estimates, "
    "not official academic results."
)

# Sidebar inputs
st.sidebar.header("Enter Student Details")

attendance = st.sidebar.slider(
    "Attendance (%)", 0, 100, 80
)
study_hours = st.sidebar.slider(
    "Daily Study Hours", 0.0, 12.0, 4.0, 0.5
)
previous_marks = st.sidebar.slider(
    "Previous Marks (%)", 0, 100, 70
)
assignment_score = st.sidebar.slider(
    "Assignment Score (%)", 0, 100, 75
)

student = pd.DataFrame([{
    "Attendance": attendance,
    "StudyHours": study_hours,
    "PreviousMarks": previous_marks,
    "AssignmentScore": assignment_score
}])[features]

predicted_marks = float(
    np.clip(model.predict(student)[0], 0, 100)
)

status = (
    "Pass (Predicted)"
    if predicted_marks >= 40
    else "Needs Improvement"
)

# Top metrics
c1, c2, c3 = st.columns(3)

c1.metric("Predicted Final Marks", f"{predicted_marks:.1f}/100")
c2.metric("Predicted Status", status)
c3.metric("Dataset Students", f"{len(df):,}")

st.divider()

left, right = st.columns(2)

with left:
    st.subheader("📊 Predicted Marks")
    fig, ax = plt.subplots(figsize=(7, 3))
    ax.barh(["Predicted Marks"], [predicted_marks])
    ax.set_xlim(0, 100)
    ax.set_xlabel("Marks out of 100")
    ax.grid(axis="x", alpha=0.3)
    st.pyplot(fig)
    plt.close(fig)

with right:
    st.subheader("📈 Study Hours vs Final Marks")
    fig, ax = plt.subplots(figsize=(7, 3))
    ax.scatter(
        df["StudyHours"], df["FinalMarks"], alpha=0.4
    )
    ax.scatter(
        [study_hours], [predicted_marks],
        marker="*", s=250, label="Current prediction"
    )
    ax.set_xlabel("Study Hours")
    ax.set_ylabel("Final Marks")
    ax.legend()
    st.pyplot(fig)
    plt.close(fig)

st.subheader("📚 Dataset Preview")
st.dataframe(df.head(20), use_container_width=True)

st.subheader("📋 Model Evaluation")
X_train, X_test, y_train, y_test = train_test_split(
    df[features], df["FinalMarks"],
    test_size=0.2, random_state=42
)

evaluation_model = model
evaluation_model.fit(X_train, y_train)
test_predictions = evaluation_model.predict(X_test)

m1, m2 = st.columns(2)
m1.metric(
    "Mean Absolute Error (MAE)",
    f"{mean_absolute_error(y_test, test_predictions):.2f}"
)
m2.metric(
    "R² Score",
    f"{r2_score(y_test, test_predictions) * 100:.2f}%"
)

st.download_button(
    "Download Dataset CSV",
    data=df.to_csv(index=False).encode("utf-8"),
    file_name="student_performance_dataset.csv",
    mime="text/csv"
)

st.info(
    "Note: Dataset sample/synthetic hai. Real student data par "
    "performance alag ho sakti hai."
)

st.success("Dashboard loaded successfully!")
